<?php
return array(
	//'配置项'=>'配置值'
    'TMPL_PARSE_STRING' => array(

        '__ADMIN_URL__'=>__ROOT__.'/Public/Admin',
        'TOKEN_ON' => true,//表单令牌验证

    ),

);